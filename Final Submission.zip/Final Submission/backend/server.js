const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root', // replace with your MySQL username
  password: '', // replace with your MySQL password
  database: 'Guanhua',
  port: 3306,
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL database.');
});

// API endpoint to fetch users
app.get('/api/users', (req, res) => {
  const sql = 'SELECT * FROM Users';
  connection.query(sql, (err, results) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.json(results);
    }
  });
});

// API endpoint to insert a new user
app.post('/api/users', (req, res) => {
  const { username, password } = req.body;
  const sql = 'INSERT INTO Users (username, password) VALUES (?, ?)';
  connection.query(sql, [username, password], (err, results) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.status(201).json({ message: 'User added successfully', id: results.insertId });
    }
  });
});

// API endpoint to update a user
app.put('/api/users/:id', (req, res) => {
  const { id } = req.params;
  const { username, password } = req.body;
  const sql = 'UPDATE Users SET username = ?, password = ? WHERE id = ?';
  connection.query(sql, [username, password, id], (err, results) => {
    if (err) {
      res.status(500).send(err);
    } else if (results.affectedRows === 0) {
      res.status(404).send({ message: 'User not found' });
    } else {
      res.status(200).json({ message: 'User updated successfully' });
    }
  });
});

// API endpoint to authenticate a user
// app.post('/api/authenticate', (req, res) => {
//   const { username, password } = req.body;
//   const sql = 'SELECT * FROM Users WHERE username = ? AND password = ?';
//   connection.query(sql, [username, password], (err, results) => {
//     if (err) {
//       res.status(500).send(err);
//     } else if (results.length > 0) {
//       res.status(200).json({ message: 'Authentication successful' });
//     } else {
//       res.status(401).json({ message: 'Authentication failed' });
//     }
//   });
// });

app.post('/api/authenticate', (req, res) => {
  const { username, password } = req.body;
  
  // Directly concatenate user inputs into the SQL query (Vulnerable to SQL Injection)
  const sql = `SELECT * FROM Users WHERE username = '${username}' AND password = '${password}'`;
  connection.query(sql, (err, results) => {
    if (err) {
      res.status(500).send(err);
    } else if (results.length > 0) {
      res.status(200).json({ message: 'Authentication successful' });
    } else {
      res.status(401).json({ message: 'Authentication failed' });
    }
  });
});


// API endpoint to fetch subscribers
app.get('/api/subscribers', (req, res) => {
  const sql = 'SELECT * FROM subscribers';
  connection.query(sql, (err, results) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.json(results);
    }
  });
});

app.post('/api/subscribers', (req, res) => {
  const { supi, key, opc, uplink, downlink, sst, sd, sm_sst, sm_sd, sm_uplink, sm_downlink } = req.body;
  const insertSubscriberSql = 'INSERT INTO subscribers (supi) VALUES (?)';

  // Start a transaction
  connection.beginTransaction((err) => {
    if (err) {
      return res.status(500).send('Transaction failed');
    }

    // Insert into subscribers table
    connection.query(insertSubscriberSql, [supi], (err, results) => {
      if (err) {
        return connection.rollback(() => {
          res.status(500).send(err);
        });
      }

      const subscriberId = results.insertId;

      // Insert into security table
      const insertSecuritySql = `
        INSERT INTO security (subscriber_id, \`key\`, opc) 
        VALUES (?, ?, ?)
      `;
      connection.query(insertSecuritySql, [subscriberId, key, opc], (err) => {
        if (err) {
          return connection.rollback(() => {
            res.status(500).send(err);
          });
        }

        // Insert into am_data table
        const insertAmDataSql = `
          INSERT INTO am_data (subscriber_id, uplink, downlink, sst, sd) 
          VALUES (?, ?, ?, ?, ?)
        `;
        connection.query(insertAmDataSql, [subscriberId, uplink, downlink, sst, sd], (err) => {
          if (err) {
            return connection.rollback(() => {
              res.status(500).send(err);
            });
          }

          // Insert into smf_sel_data table with default values
          const insertSmfSelDataSql = `
            INSERT INTO smf_sel_data (subscriber_id) 
            VALUES (?)
          `;
          connection.query(insertSmfSelDataSql, [subscriberId], (err) => {
            if (err) {
              return connection.rollback(() => {
                res.status(500).send(err);
              });
            }

            // Insert into sm_data table with user inputs and default values
            const insertSmDataSql = `
              INSERT INTO sm_data (subscriber_id, sst, sd, internet_pdu_session_type, internet_ssc_mode, session_uplink, session_downlink) 
              VALUES (?, ?, ?, 'IPV4', 'SSC_MODE_1', ?, ?)
            `;
            connection.query(insertSmDataSql, [subscriberId, sm_sst, sm_sd, sm_uplink, sm_downlink], (err) => {
              if (err) {
                return connection.rollback(() => {
                  res.status(500).send(err);
                });
              }

              // Commit the transaction
              connection.commit((err) => {
                if (err) {
                  return connection.rollback(() => {
                    res.status(500).send('Transaction commit failed');
                  });
                }
                res.status(201).json({ message: 'Subscriber, security, AM data, SMF selection data, and SM data added successfully', subscriberId });
              });
            });
          });
        });
      });
    });
  });
});


// Start server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
