import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { UserService } from './user.service';
import { NetworkHomeComponent } from './network-home/network-home.component';  // Ensure this path is correct
import { AppRoutingModule } from './app-routing.module';
import { AddSubscriberComponent } from './add-subscriber/add-subscriber.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginFormComponent,
    NetworkHomeComponent,
    AddSubscriberComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [UserService],  // Optional if providedIn: 'root' is used in UserService
  bootstrap: [AppComponent],
})
export class AppModule { }
