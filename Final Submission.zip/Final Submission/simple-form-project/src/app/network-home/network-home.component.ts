import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-network-home',
  templateUrl: './network-home.component.html',
  styleUrls: ['./network-home.component.css']
})
export class NetworkHomeComponent implements OnInit {
  subscribers: any[] = [];
  showNavbar: boolean = true;  // Define showNavbar and set it to true

  constructor(
    private userService: UserService,
    private router: Router,  // Inject Router here
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.params.subscribe(() => {
      this.fetchSubscribers();  // Fetch the latest data when the component is activated
    });
  }

  fetchSubscribers() {
    this.userService.getSubscribers().subscribe((data) => {
      this.subscribers = data;
    });
  }

  addRandomSubscriber(event: MouseEvent) {
    event.preventDefault();  // Prevent the default anchor click behavior

    const randomSupi = Math.floor(10000000 + Math.random() * 90000000).toString(); // Generate a random 8-digit number
    const randomSubscriber = {
      supi: randomSupi,
      key: 'randomKey123',  // Example random data
      opc: 'randomOpc123',  // Example random data
      uplink: '104857600',  // Example random data
      downlink: '104857600',  // Example random data
      sst: 1,  // Example random data
      sd: '000001',  // Example random data
      sm_sst: 1,  // Example random data
      sm_sd: '000001',  // Example random data
      sm_uplink: '81920000',  // Example random data
      sm_downlink: '81920000',  // Example random data
    };

    this.userService.addSubscriber(randomSubscriber).subscribe(
      (response) => {
        console.log('Random subscriber added:', response);
        this.fetchSubscribers();  // Refresh the subscriber list
        this.router.navigate(['/NetworkHome']); // Navigate to NetworkHome after adding
      },
      (error) => {
        console.error('Error adding random subscriber:', error);
      }
    );
  }
}
