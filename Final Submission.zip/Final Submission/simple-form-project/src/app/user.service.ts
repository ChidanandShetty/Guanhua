import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private apiUrl = 'http://localhost:3000/api/users';
  private authUrl = 'http://localhost:3000/api/authenticate';  // New URL for authentication
  private subscribersUrl = 'http://localhost:3000/api/subscribers';  // New URL for subscribers

  constructor(private http: HttpClient) {}

  getUsers(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  addUser(user: { username: string; password: string }): Observable<any> {
    return this.http.post(this.apiUrl, user);
  }

  updateUser(id: number, user: { username: string; password: string }): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, user);
  }

  authenticate(user: { username: string; password: string }): Observable<any> {
    return this.http.post(this.authUrl, user);  // New method for authentication
  }

  getSubscribers(): Observable<any> {  // New method to fetch subscribers
    return this.http.get(this.subscribersUrl);
  }

  addSubscriber(subscriber: { 
    supi: string; 
    key: string; 
    opc: string; 
    uplink: string; 
    downlink: string; 
    sst: number; 
    sd: string;
    sm_sst: number;
    sm_sd: string;
    sm_uplink: string;
    sm_downlink: string;
  }): Observable<any> {
    return this.http.post(`${this.subscribersUrl}`, subscriber);
  }
  
}
