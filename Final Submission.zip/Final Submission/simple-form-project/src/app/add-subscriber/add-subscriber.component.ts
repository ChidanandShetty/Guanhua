import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-subscriber',
  templateUrl: './add-subscriber.component.html',
  styleUrls: ['./add-subscriber.component.css']
})
export class AddSubscriberComponent {

  showNavbar: boolean = true;  // Define showNavbar and set it to true

  supi: string = '';
  key: string = '';
  opc: string = '';
  uplink: string = '';
  downlink: string = '';
  sst: number | null = null;
  sd: string = '';

  sm_sst: number | null = null;
  sm_sd: string = '';
  sm_uplink: string = '';
  sm_downlink: string = '';

  constructor(private userService: UserService, private router: Router) {}

  onSubmit() {
    const newSubscriber = {
      supi: this.supi,
      key: this.key,
      opc: this.opc,
      uplink: this.uplink,
      downlink: this.downlink,
      sst: this.sst ?? 0,  // Use a default value if sst is null
      sd: this.sd,
      sm_sst: this.sm_sst ?? 0,  // Use a default value if sm_sst is null
      sm_sd: this.sm_sd,
      sm_uplink: this.sm_uplink,
      sm_downlink: this.sm_downlink,
    };
  
    this.userService.addSubscriber(newSubscriber).subscribe(
      (response) => {
        console.log('Subscriber added:', response);
        this.router.navigate(['/NetworkHome']);  // Redirect to NetworkHome after adding
      },
      (error) => {
        console.error('Error adding subscriber:', error);
      }
    );
  }

  addRandomSubscriber(event: MouseEvent) {
    event.preventDefault();  // Prevent the default anchor click behavior
  
    const randomSupi = Math.floor(10000000 + Math.random() * 90000000).toString(); // Generate a random 8-digit number
    const randomSubscriber = {
      supi: randomSupi,
      key: 'randomKey123',  // Example random data
      opc: 'randomOpc123',  // Example random data
      uplink: '104857600',  // Example random data
      downlink: '104857600',  // Example random data
      sst: 1,  // Example random data
      sd: '000001',  // Example random data
      sm_sst: 1,  // Example random data
      sm_sd: '000001',  // Example random data
      sm_uplink: '81920000',  // Example random data
      sm_downlink: '81920000',  // Example random data
    };
  
    this.userService.addSubscriber(randomSubscriber).subscribe(
      (response) => {
        console.log('Random subscriber added:', response);
        this.router.navigate(['/NetworkHome']); // Navigate to NetworkHome after adding
      },
      (error) => {
        console.error('Error adding random subscriber:', error);
      }
    );
  }
  

}
