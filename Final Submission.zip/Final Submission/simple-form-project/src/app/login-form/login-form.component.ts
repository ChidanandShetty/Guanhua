import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';  // Adjust this path if your service is located elsewhere

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css'],
})
export class LoginFormComponent {
  username: string = '';
  password: string = '';

  constructor(private userService: UserService, private router: Router) {}

  onSubmit() {
    const user = { username: this.username, password: this.password };
    this.userService.authenticate(user).subscribe(
      (response) => {
        console.log(response.message);  // Handle successful authentication
        // You can navigate to another page or show a success message
        //this.router.navigate(['/NetworkHome']);  // Redirect to the NetworkHome component on success
        this.router.navigate(['/NetworkHome']).then(success => {
          if (success) {
            console.log('Navigation successful!');
          } else {
            console.log('Navigation failed!');
          }
        });
        
      },
      (error) => {
        console.error(error.message);  // Handle failed authentication
        // You can show an error message to the user
      }
    );
  }
}
