import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';
import { NavigationEnd, Router, Event } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'simple-form-project';
  showNavbar: boolean = false;
  subscribers: any[] = []; // Define the subscribers array

  constructor(private userService: UserService, private router: Router) {}

  ngOnInit() {
    this.router.events
      .pipe(filter((event: Event): event is NavigationEnd => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        // Show navbar only on NetworkHome and AddSubscriber routes
        this.showNavbar = event.urlAfterRedirects === '/NetworkHome' || event.urlAfterRedirects === '/addSubscriber';
      });

    this.fetchSubscribers();
  }

 
  fetchSubscribers() {
    this.userService.getSubscribers().subscribe((data) => {
      this.subscribers = data;
    });
  }
}
